//By: Hitam Yadav

public class Complexity {
	
	//O(n2)
	public void method1(int n) { 
		int counter = 0;
		for (int i = 0; i < n; ++i) {
			for (int j = 0; j < n; ++j) {
				System.out.println("Operation: " +counter); 
				++counter;
			}
		}
	}

	//O(n3)
	public void method2(int n) { 
		int counter = 0;
		for (int i = 0; i < n; ++i) {
			for (int j = 0; j < n; ++j) {
				for (int k = 0; k < n; ++k) {
					System.out.println("Operation: " + counter); 
					++counter;
				}
			}
		}
	}
	
	//O(logn)
   public void method3(int n) { 
	   int counter = 0, i = 2;
       while (i <= n) {
    	   System.out.println("Operation: " + counter); 
    	   ++counter;
           i = i * 2;
           }
       }

   //O(nlogn)
   public void method4(int n) { 
	   int counter = 0, i = 0;
       for (int j = 0; j < n; ++j) {
           i = 2;
           while (i <= n) {
               System.out.println("Operation: " + counter); 
               ++counter;
               i = i * 2;
           }
       }
   }
   
  // O(loglogn)
   public void method5(int n) {
	   int counter = 0, i = 2;
       while (i <= n) {
    	   ++counter;
           i = i * 2;
           }
       
       int counter2 = 0, j=2;
       while (j <= counter) {
    	   System.out.println("Operation: " + counter2); 
    	   ++counter2;
           j = j * 2;
           }
	   
   }
}